# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_verifpal_global_optspecs
    string join \n h/help V/version
end

function __fish_verifpal_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_verifpal_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_verifpal_using_subcommand
    set -l cmd (__fish_verifpal_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c verifpal -n "__fish_verifpal_needs_command" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c verifpal -n "__fish_verifpal_needs_command" -s V -l version -d 'Print version'
complete -c verifpal -n "__fish_verifpal_needs_command" -f -a "verify" -d 'Analyze protocol models and report attacks against their queries'
complete -c verifpal -n "__fish_verifpal_needs_command" -f -a "pretty" -d 'Reformat models into the canonical Verifpal style'
complete -c verifpal -n "__fish_verifpal_needs_command" -f -a "diagram" -d 'Emit a Mermaid sequence diagram of a model'
complete -c verifpal -n "__fish_verifpal_needs_command" -f -a "about" -d 'Print version, homepage and contributor credits'
complete -c verifpal -n "__fish_verifpal_needs_command" -f -a "lsp" -d 'Run the Verifpal language server over stdio'
complete -c verifpal -n "__fish_verifpal_needs_command" -f -a "completion" -d 'Print a shell completion script to stdout'
complete -c verifpal -n "__fish_verifpal_needs_command" -f -a "man" -d 'Print the roff source of the verifpal(1) manual page to stdout'
complete -c verifpal -n "__fish_verifpal_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -l sessions -d 'Concurrent sessions to analyze per principal [1-16]' -r
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -l format -d 'Report as text, JSON or a self-contained HTML page' -r -f -a "text\t''
json\t''
html\t''"
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -l color -d 'When to color the output: auto, always or never' -r -f -a "auto\t''
always\t''
never\t''"
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -l result-code -d 'Print the compact one-letter-per-query result code'
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -l fail-on-attack -d 'Exit with status 2 if any query was broken'
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -l auto-queries -d 'Replace the model\'s queries with a generated set'
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -l saturate -d 'Raise the session count until the verdicts stop changing'
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -s q -l quiet -d 'Print query verdicts and warnings only'
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -s v -l verbose -d 'Print every deduction and analysis step'
complete -c verifpal -n "__fish_verifpal_using_subcommand verify" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c verifpal -n "__fish_verifpal_using_subcommand pretty" -s w -l write -d 'Rewrite the files in place instead of printing'
complete -c verifpal -n "__fish_verifpal_using_subcommand pretty" -l check -d 'Report which files are not canonically formatted'
complete -c verifpal -n "__fish_verifpal_using_subcommand pretty" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c verifpal -n "__fish_verifpal_using_subcommand diagram" -l color -d 'When to color the output: auto, always or never' -r -f -a "auto\t''
always\t''
never\t''"
complete -c verifpal -n "__fish_verifpal_using_subcommand diagram" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c verifpal -n "__fish_verifpal_using_subcommand about" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c verifpal -n "__fish_verifpal_using_subcommand lsp" -l stdio -d 'Accepted for compatibility; stdio is the only transport'
complete -c verifpal -n "__fish_verifpal_using_subcommand lsp" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c verifpal -n "__fish_verifpal_using_subcommand completion" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c verifpal -n "__fish_verifpal_using_subcommand man" -l output -d 'Write one page per command into DIR instead of printing to stdout' -r
complete -c verifpal -n "__fish_verifpal_using_subcommand man" -s h -l help -d 'Print help'
complete -c verifpal -n "__fish_verifpal_using_subcommand help; and not __fish_seen_subcommand_from verify pretty diagram about lsp completion man help" -f -a "verify" -d 'Analyze protocol models and report attacks against their queries'
complete -c verifpal -n "__fish_verifpal_using_subcommand help; and not __fish_seen_subcommand_from verify pretty diagram about lsp completion man help" -f -a "pretty" -d 'Reformat models into the canonical Verifpal style'
complete -c verifpal -n "__fish_verifpal_using_subcommand help; and not __fish_seen_subcommand_from verify pretty diagram about lsp completion man help" -f -a "diagram" -d 'Emit a Mermaid sequence diagram of a model'
complete -c verifpal -n "__fish_verifpal_using_subcommand help; and not __fish_seen_subcommand_from verify pretty diagram about lsp completion man help" -f -a "about" -d 'Print version, homepage and contributor credits'
complete -c verifpal -n "__fish_verifpal_using_subcommand help; and not __fish_seen_subcommand_from verify pretty diagram about lsp completion man help" -f -a "lsp" -d 'Run the Verifpal language server over stdio'
complete -c verifpal -n "__fish_verifpal_using_subcommand help; and not __fish_seen_subcommand_from verify pretty diagram about lsp completion man help" -f -a "completion" -d 'Print a shell completion script to stdout'
complete -c verifpal -n "__fish_verifpal_using_subcommand help; and not __fish_seen_subcommand_from verify pretty diagram about lsp completion man help" -f -a "man" -d 'Print the roff source of the verifpal(1) manual page to stdout'
complete -c verifpal -n "__fish_verifpal_using_subcommand help; and not __fish_seen_subcommand_from verify pretty diagram about lsp completion man help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
